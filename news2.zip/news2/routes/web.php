<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/','App\Http\Controllers\NewsController@index');
Route::get('/manage','App\Http\Controllers\NewsController@home');
Route::get('/login','Auth\LoginController@getLogin');
 


Route::post('/admin_login','App\Http\Controllers\Auth\LoginController@postLogin');

Route::post('/search','App\Http\Controllers\NewsController@search');
Route::group(['middleware' => 'userAuth'], function () {
    Route::get('/dasboard', 'HomeController@home');
	
});
