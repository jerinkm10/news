<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use DB;
class NewsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $response = Http::get('https://newsapi.org/v2/everything?pageSize=10&q=Kerala&sortBy=publishedAt&apiKey=9dbd973a307d4667a14edfcd8738930e');
        //dd($response->object()->articles);
        return view('welcome',['data'=>$response->object()->articles]);
    }
    public function home()
    {
       
        //dd($response->object()->articles);
        return view('admin');
    }
   

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $search = $request->get('search');
            $searching = DB::table('sreach')
                ->where('sreach_name', $search)
                //->select('*')
            ->get();
            //
        if($searching->isEmpty()){
            //dd($searching);
            $sreach_id = DB::table('sreach')->insertGetId(
                [   
                    'sreach_name'		    => $search,
                    'sreach_status'		    => 1
                
            ]);
            
            $response = Http::get('https://newsapi.org/v2/everything?pageSize='.$request->get('id').'&q=Kerala&sortBy=publishedAt&apiKey=9dbd973a307d4667a14edfcd8738930e');
            foreach($response->object()->articles as $value){
                DB::table('sreach_groupe')->insert(
                    [   
                        'sreach_id'		    => $sreach_id,
                        'author'		    => $value->author,
                        'title'		        => $value->title,
                        'description'		=> $value->description,
                        'urlToImage'		=> $value->urlToImage,
                        'publishedAt'		=> $value->publishedAt,
                        'content'		=> $value->content
                    
                ]);
            }
            return [ 'success' => 1, 'status' => 'Success..!!',  'data' => $response->object()->articles];
        }else{
            foreach($searching as $value){
                $sreach_id = $value->sreach_id;
            }
            $searches = DB::table('sreach_groupe')
                ->where('sreach_id', $sreach_id)
                //->select('*')
            ->get();
            //$response = Http::get('https://newsapi.org/v2/everything?pageSize='.$request->get('id').'&q='.$request->get('search').'&sortBy=publishedAt&apiKey=9dbd973a307d4667a14edfcd8738930e');
            
        }
        //dd($searches);
        return [ 'success' => 1, 'status' => 'Success..!!',  'data' => $searches];
      
       // dd();
       
        //return view('welcome',['data'=>$response->object()->articles]); 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
