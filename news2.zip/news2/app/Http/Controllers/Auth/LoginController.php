<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Hash;
use Redirect;
use Session;
use DB;
use Validator;

class LoginController extends Controller
{

    public function getLogin(){
        return view('welcome');
    }

    public function postLogin(Request $request){
        //try {
            $message = trans('messages.invalid_login_credentials');
            $rememberMe = false;
            $user = User::where('email', $request->email)->where('status', 1)->first();
            if (!empty($user)) {
                //Session::set('user_id', $user->id);
                session(['empolyee_id' => $user->emple_id]);
                session(['employee_name' => $user->name]);
                session(['employee_email' => $user->email]);
                session(['employee_role' => $user->role]);
                session(['employee_team' => $user->team]);
                    if ($request->password == $user->password) {
                        Auth::loginUsingId($user->id, $rememberMe);
                        if(function_exists('date_default_timezone_set')) {
                            date_default_timezone_set("Asia/Kolkata");
                        }
                        $date=date("Y-m-d");
                        $time = date("H:i a");
                        $date_employee = DB::table('employee_login')
                        ->where('employee_login_status', 'SUBMITED')
                        ->where('employee_login_emp_id', $user->emple_id)
                        ->where('employee_login_date', $date)
                       // ->select('*')
                        ->first();
                        //dd($date_employee);
                        if(empty($date_employee)){
                        DB::table('employee_login')->insert(
                            [   
                                'employee_login_name'		=> Session::get('employee_name'),
                                'employee_login_emp_id'		=> Session::get('empolyee_id'),
                                'employee_login_date'		=> $date,
                                'employee_login_time'		=> $time, 
                                'employee_login_status'	=> 'SUBMITED' 
                               
                       ]);}
                        return redirect('/dasboard');
                    }
					else {
					return redirect('/Error');
					}
                }
				else {
					return redirect('/Error');
				}
     //   } catch (\Exception $e) {
     //       Log::error(__CLASS__ . "::" . __METHOD__ . "  " . $e->getMessage() . "on line" . $e->getLine());
     //   }
    //    return redirect('/login')->with('error_msg', $message);
    }


    public function logoutUser(Request $request){
       // $user = User::where('emple_id',Session::get('employee_role'))->where('status', 1)->first();
        Auth::logout();
        if(function_exists('date_default_timezone_set')) {
            date_default_timezone_set("Asia/Kolkata");
        }
        $date=date("Y-m-d");
        $time = date("H:i a");
        $date_employee = DB::table('employee_login')
        ->where('employee_login_status', 'LOGOUT')
        ->where('employee_login_emp_id',  Session::get('empolyee_id'))
        ->where('employee_login_date', $date)
       // ->select('*')
        ->first();
        //dd($date_employee);
        if(empty($date_employee)){
                DB::table('employee_login')->insert(
                    [   
                        'employee_login_name'		=> Session::get('employee_name'),
                        'employee_login_emp_id'		=> Session::get('empolyee_id'),
                        'employee_login_date'		=> $date,
                        'employee_login_time'		=> $time, 
                        'employee_login_status'	=> 'LOGOUT' 
                     ]);
        } else {
            DB::table('employee_login')
                ->where('employee_login_status', 'LOGOUT')
                ->where('employee_login_date', $date)
                ->delete();
        DB::table('employee_login')->insert(
            [   
                'employee_login_name'		=> Session::get('employee_name'),
                'employee_login_emp_id'		=> Session::get('empolyee_id'),
                'employee_login_date'		=> $date,
                'employee_login_time'		=> $time, 
                'employee_login_status'	=> 'LOGOUT' 
            ]);

        }
        return redirect('/login');
    }

}