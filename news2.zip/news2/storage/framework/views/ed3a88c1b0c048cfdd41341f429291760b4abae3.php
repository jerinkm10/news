
<?php $__env->startSection("content"); ?>
<div class="container">
  <div class="row">
    <div class="col-md-4 offset-4">
      <div class="login-box">
        <img src="<?php echo e(url('public/images/logo-color.png')); ?>" class="logo">
        <div class="login-cover">
          <h3>Login</h3>
          <form method="post" action="/admin_login" class="mt-5 mb-5 login-input">
          <?php echo csrf_field(); ?>
                <label>Employee ID /Guest</label>
                <input type="text" class="form-control" name="email">
                <label>Password</label>
                <input type="password" class="form-control" name="password">
                <button class="btn btn-primary btn-login" type="submit" name="" value="">Login</button>
                <a href="index.html" class="forgot">Forgot Password</a>
                <h5>Powered by Exacore Digital <?php echo date("Y"); ?></h5>
         </form>
        </div>
      </div>
    </div>  
  </div> 
</div>                         
<?php $__env->stopSection(); ?>
<?php echo $__env->make("login.login", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\news2\resources\views/admin.blade.php ENDPATH**/ ?>