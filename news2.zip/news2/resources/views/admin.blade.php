@extends("login.login")
@section("content")
<div class="container">
  <div class="row">
    <div class="col-md-4 offset-4">
      <div class="login-box">
        <img src="{{ url('public/images/logo-color.png')}}" class="logo">
        <div class="login-cover">
          <h3>Login</h3>
          <form method="post" action="/admin_login" class="mt-5 mb-5 login-input">
          @csrf
                <label>Employee ID /Guest</label>
                <input type="text" class="form-control" name="email">
                <label>Password</label>
                <input type="password" class="form-control" name="password">
                <button class="btn btn-primary btn-login" type="submit" name="" value="">Login</button>
                <a href="index.html" class="forgot">Forgot Password</a>
                <h5>Powered by Exacore Digital <?php echo date("Y"); ?></h5>
         </form>
        </div>
      </div>
    </div>  
  </div> 
</div>                         
@endsection